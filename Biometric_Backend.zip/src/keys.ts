//variables de conexion a la bd
/* LOCAL
export default{
    database:{
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'biometric',
        port:3306
    }
}


export default{
    database:{
        host: 'localhost',
        user: 'ugmmkojk_biometric_user',
        password: '6,f#Z5i)5C=q',
        database: 'ugmmkojk_biometric',
        port:3306
    }
}*/

export default{
    database:{
        host: 'localhost',
        user: 'ugmmkojk_guillermo',
        password: 'tJY.M*X,wNgO',
        database: 'ugmmkojk_example',
        port:3306
    }
}