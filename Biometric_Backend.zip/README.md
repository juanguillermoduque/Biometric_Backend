# Biometric_Backend

Dependencias que solicitan instalación
-nodemon
-tsc

installar nodemon:

    npm i nodemon

installar tsc:

    npm i typescript

Instalar paquetes de node

    npm install

Para lograr la ejecucion del projesto se realiza el siguiente comando:

    npm run dev

Para realizar modificaciones y correr el building de javaScript se realiza el siguente comando desde una terminal nueva:

    npm run build
